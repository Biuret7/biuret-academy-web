#!/usr/bin/env python3
"""Standalone flag checker. Requires Python 3.9+ and no dependencies."""
import hashlib
import hmac

SALT = 'B1URET-CTF-03-v1-2026'
EXPECTED = 'da55fc7a2ea3640439ec66ee0baf4e5bb17c2a66189e27556139d116d1da9058'

def main():
    print('Biuret CTF | Flag Validator')
    candidate = input('Enter flag: ').strip()
    submitted = hashlib.sha256((SALT + '::' + candidate).encode('utf-8')).hexdigest()
    if hmac.compare_digest(submitted, EXPECTED):
        print('SUCCESS - Correct flag!')
        return 0
    print('Incorrect flag. Keep investigating.')
    return 1

if __name__ == '__main__':
    raise SystemExit(main())
