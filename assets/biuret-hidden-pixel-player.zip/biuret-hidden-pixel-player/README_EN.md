# 03 — Hidden Pixel | Steganography | Easy (1/5)

The RGB image `evidence.png` hides a UTF-8 proof token in the lowest bit of its **red** channel. Read pixels row-major from top left, most-significant bit first within bytes. The stream starts with a 4-byte marker, then a 2-byte big-endian payload length, then the payload. Install `Pillow` using `python -m pip install -r requirements.txt`; complete optional `extract_starter.py`, then validate via `python verify.py`. Score: bit recovery (4), header/length (3), flag (3).
