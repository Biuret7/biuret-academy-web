"""Beginner starter. Install Pillow: python -m pip install -r requirements.txt"""
from pathlib import Path
from PIL import Image

picture = Image.open(Path(__file__).with_name("evidence.png")).convert("RGB")
print("Image dimensions:", picture.size)

bits = []
for red, green, blue in picture.getdata():
    # TODO 1: Append the LEAST SIGNIFICANT bit of the red channel.
    # Hint: red & 1
    pass

# TODO 2: Group every 8 bits into one byte (MSB first).
# TODO 3: First 4 bytes identify the format; next 2 = length.
# TODO 4: Decode exactly that many payload bytes as UTF-8.
# TODO 5: Print the result, then run verify.py.
