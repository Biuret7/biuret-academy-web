#!/usr/bin/env python3
"""Standalone flag checker. Requires Python 3.9+ and no dependencies."""
import hashlib
import hmac

SALT = 'B1URET-CTF-01-v1-2026'
EXPECTED = 'f6c5e551ac2bf3b76b93bf4e45e1b8404ae5ba5892a17161605293c6f4a5512a'

def main():
    print('Biuret CTF | Flag Validator')
    candidate = input('Enter flag: ').strip()
    submitted = hashlib.sha256((SALT + '::' + candidate).encode('utf-8')).hexdigest()
    if hmac.compare_digest(submitted, EXPECTED):
        print('SUCCESS - Correct flag!')
        return 0
    print('Incorrect flag. Keep investigating.')
    return 1

if __name__ == '__main__':
    raise SystemExit(main())
