# Optional learning skeleton — fill in the TODO sections.
from pathlib import Path

cipher = Path(__file__).with_name("cipher.txt").read_text(encoding="utf-8")

for shift in range(26):
    decoded = ""
    for char in cipher:
        # TODO: If char is A-Z, move BACK by `shift` positions.
        # Use ord(), chr(), and % 26. Preserve spaces and punctuation.
        decoded += char
    print(f"--- Shift {shift} ---")
    print(decoded)
