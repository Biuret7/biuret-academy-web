# 01 — Hidden Message | Cryptography | Easy (1/5)

An intercepted archive message uses a constant alphabetical shift (Caesar cipher). Recover the shift, decipher `cipher.txt`, then submit the `FLAG{...}` value using `python verify.py`.

You can use the optional `starter.py` script. No third-party packages or internet required. Scoring: shift (3), decoded message (3), correct flag (4). Progressive hints are in `HINTS.md`.
