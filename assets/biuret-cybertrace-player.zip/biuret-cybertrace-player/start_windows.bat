@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
where py >nul 2>&1
if %errorlevel%==0 (
    py -3 -X utf8 cybertrace.py
) else (
    python -X utf8 cybertrace.py
)
if errorlevel 1 echo [ERROR] Install Python 3.10 or newer and try again.
pause
