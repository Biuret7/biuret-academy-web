#!/usr/bin/env python3
"""Biuret CyberTrace - self-contained, local investigation simulator.

All sample data is invented. Its legacy dispatcher runs simulated read-only
commands; it never forwards user strings to the host operating-system shell.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import shlex
import sys

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'evidence'
NOTES = EVIDENCE / 'notes'
PROTECTED = ROOT / 'restricted'
CASE_ID = 'CT-2026-017'
EXPECTED_FLAG_SHA256 = 'aebbc6f89a69c7bd574bb5c0a19bb84562d5bd678308dc22414cc33f562aa233'


def load_json(relative):
    return json.loads((ROOT / relative).read_text(encoding='utf-8'))


def load_csv(relative):
    with (ROOT / relative).open('r', encoding='utf-8', newline='') as handle:
        return list(csv.DictReader(handle))


def head(title):
    print('\n' + '─' * 77)
    print('  ' + title)
    print('─' * 77)


def table(rows, columns, limit=None):
    if limit is not None:
        rows = rows[:limit]
    if not rows:
        print('  No entries.')
        return
    widths = []
    for col, label, maximum in columns:
        widths.append(min(max(len(label), *(len(str(row.get(col, ''))) for row in rows)), maximum))
    fmt = lambda value, w: str(value).replace('\n',' ')[:w].ljust(w)
    print('  ' + '  '.join(fmt(label, w) for (_, label, _), w in zip(columns, widths)))
    print('  ' + '  '.join('─' * w for w in widths))
    for row in rows:
        print('  ' + '  '.join(fmt(row.get(col, ''), w) for (col,_,_),w in zip(columns,widths)))


def cmd_help():
    print("""
  case                       Show case briefing
  employees                  Show staff roster
  auth [N]                   Show authentication activity (optional row limit)
  network [N]                Show network connections
  files [N]                  Show file activity
  notes                      List investigation notes
  read <note-name>           Read an investigation note
  integrity list             List reference integrity hashes
  integrity check <path>     Verify a workstation evidence file
  fragments                  Show fragmented evidence location
  report                     Show investigation objectives
  submit <FLAG{...}>         Check a proposed final flag
  help                       Show commands
  clear                      Clear display
  exit                       Close console
""")


def show_case():
    head('CASE BRIEF · ' + CASE_ID)
    print('  Alert    : Unexplained outgoing traffic on 2026-09-24')
    print('  Priority : HIGH')
    print('  Timezone : UTC (all recorded timestamps)')
    print('  Mission  : Correlate the evidence, identify the actor and recover the')
    print('             sealed custody record. Submit the reconstructed final flag.')
    print('  Source   : Fictional training dataset; all IP ranges are illustrative.')


def cmd_employees():
    head('EMPLOYEE DIRECTORY')
    table(load_json('evidence/employees.json')['employees'],[
        ('employee_id','EMP ID',7),('name','NAME',19),('department','DEPARTMENT',21),('workstation','HOST',9)])


def cmd_auth(n):
    head('AUTHENTICATION / SESSION AUDIT')
    table(load_csv('evidence/auth_logs.csv'),[
        ('timestamp_utc','UTC TIME',20),('employee_id','EMP',6),('host','HOST',7),
        ('session_id','SESSION',8),('event','ACTION',16),('status','STATUS',8)],n)


def cmd_network(n):
    head('NETWORK EGRESS TELEMETRY')
    rows=load_json('evidence/network_connections.json')['connections']
    table(rows,[('timestamp_utc','UTC TIME',20),('host','HOST',7),('session_id','SESSION',8),
                ('destination_ip','DESTINATION',15),('bytes_out','BYTES OUT',10),
                ('classification','CLASSIFICATION',24)],n)


def cmd_files(n):
    head('FILE EVENTS')
    table(load_csv('evidence/file_events.csv'),[
        ('timestamp_utc','UTC TIME',20),('host','HOST',7),('session_id','SESSION',8),
        ('action','ACTION',16),('path','FILE PATH',42)],n)


def cmd_notes():
    head('AVAILABLE NOTES')
    for file in sorted(NOTES.glob('*.txt')):
        print('  ' + file.name)


def cmd_read(name):
    # Note viewer enforces boundaries: this feature is intentionally safe.
    path=(NOTES / name).resolve()
    if not path.is_relative_to(NOTES.resolve()) or not path.is_file() or path.suffix!='.txt':
        print('  [DENIED] Only named .txt files inside the notes folder are available.')
        return
    head(name)
    print(path.read_text(encoding='utf-8'))


def baseline():
    return load_json('evidence/integrity_baseline.json')['files']


def cmd_integrity_list():
    head('TRUSTED HASH BASELINE')
    table(baseline(),[('path','PATH',53),('expected_sha256','EXPECTED SHA256',64)])


def _simulated_dispatch(statement):
    """Read-only virtual command dispatcher. Not a real shell or subprocess."""
    for piece in statement.split(';'):
        piece=piece.strip()
        if not piece:
            continue
        try:
            parts=shlex.split(piece)
        except ValueError:
            print('  [DISPATCH] Malformed command text.')
            return
        if not parts:
            continue
        op,*args=parts
        if op=='digest' and len(args)==1:
            _virtual_digest(args[0])
        elif op=='casefile' and len(args)==1:
            _virtual_casefile(args[0])
        else:
            print(f'  [DISPATCH] Unknown virtual operation: {op}')


def _virtual_digest(label):
    base=EVIDENCE.resolve()
    path=(ROOT / label).resolve()
    if not path.is_relative_to(base) or not path.is_file():
        print('  [DIGEST] Evidence path unavailable.')
        return
    allowed={entry['path']:entry['expected_sha256'] for entry in baseline()}
    if label not in allowed:
        print('  [DIGEST] No trusted baseline for this evidence item.')
        return
    actual=hashlib.sha256(path.read_bytes()).hexdigest()
    print('  File     : ' + label)
    print('  Expected : ' + allowed[label])
    print('  Actual   : ' + actual)
    print('  Integrity: ' + ('MATCH' if actual==allowed[label] else 'MISMATCH'))


def _virtual_casefile(identifier):
    # Internal case-file operation: retained for archival compatibility.
    # It must not be accessible through the public investigation menu.
    if identifier != 'seal-017':
        print('  [CASEFILE] Receipt not found.')
        return
    path=PROTECTED / (identifier + '.json')
    print('  [CASEFILE] ARCHIVED RECEIPT · ENCRYPTED')
    print(path.read_text(encoding='utf-8'))


def cmd_integrity_check(user_value):
    # Legacy verify gateway. It constructs a command-like statement from input.
    # A virtual dispatcher processes that statement, NOT the host shell.
    statement='digest ' + user_value
    _simulated_dispatch(statement)


def cmd_fragments():
    rows=load_csv('evidence/fragments.csv')
    head('FRAGMENTED HANDOFF MEMO')
    print('  Location : evidence/fragments.csv')
    print('  Rows     : ' + str(len(rows)))
    print('  Columns  : case, part, chunk_b64, crc32')
    print('  Integrity: CRC32 of decoded bytes; discard mismatching fragments.')
    print('  Encoding : individual base64-encoded byte chunks')
    print('  Hint     : filter by case ID, validate checksums, order by part.')


def cmd_report():
    head('INVESTIGATION CHECKLIST')
    print("""  [ ] Confirm suspicious destination, time and transferred byte count.
  [ ] Correlate employee ID, session ID, workstation and archive.
  [ ] Detect altered workstation evidence using the trusted baseline.
  [ ] Reassemble a valid handoff memo with a short Python script.
  [ ] Audit the verification command path for an unintended operation.
  [ ] Recover and interpret the sealed custody record.
  [ ] Submit the derived flag.
""")


def cmd_submit(value):
    if hashlib.sha256(value.encode('utf-8')).hexdigest()==EXPECTED_FLAG_SHA256:
        print('\n  ╔══════════════════════════════════════════════════════════╗')
        print('  ║    SUCCESS · BIURET CYBERTRACE CASE RESOLVED             ║')
        print('  ╚══════════════════════════════════════════════════════════╝')
    else:
        print('  [REJECTED] The proposed case flag does not match.')


def clear():
    print('\n'*35)


def accept_count(argument):
    if not argument:
        return None
    if not argument.isdigit() or int(argument)<1:
        raise ValueError('Use a positive integer row limit.')
    return int(argument)


def dispatch(line):
    parts=line.strip().split(maxsplit=2)
    if not parts:
        return True
    cmd=parts[0].lower()
    rest=line.strip()[len(parts[0]):].strip()
    if cmd=='help':cmd_help()
    elif cmd=='case':show_case()
    elif cmd=='employees':cmd_employees()
    elif cmd=='auth':cmd_auth(accept_count(rest))
    elif cmd=='network':cmd_network(accept_count(rest))
    elif cmd=='files':cmd_files(accept_count(rest))
    elif cmd=='notes':cmd_notes()
    elif cmd=='read' and rest:cmd_read(rest)
    elif cmd=='integrity':
        inner=rest.split(maxsplit=1)
        if inner and inner[0]=='list':cmd_integrity_list()
        elif len(inner)==2 and inner[0]=='check':cmd_integrity_check(inner[1])
        else:print('  Usage: integrity list | integrity check <path>')
    elif cmd=='fragments':cmd_fragments()
    elif cmd=='report':cmd_report()
    elif cmd=='submit' and rest:cmd_submit(rest)
    elif cmd=='clear':clear()
    elif cmd in ('exit','quit'):
        print('  Investigation session closed.')
        return False
    else:print('  Unknown command. Type help.')
    return True


def main(argv=None):
    parser=argparse.ArgumentParser(description='Biuret CyberTrace training console')
    parser.add_argument('--version',action='version',version='Biuret CyberTrace 1.0 · CT-2026-017')
    args=parser.parse_args(argv)
    print('  ╔══════════════════════════════════════════════════════════╗')
    print('  ║  BIURET CYBERTRACE     ·     INCIDENT RESPONSE CONSOLE   ║')
    print('  ║  CASE CT-2026-017     ·     FICTIONAL SECURITY LAB        ║')
    print('  ╚══════════════════════════════════════════════════════════╝')
    print('  Type help to list commands. Type report for mission objectives.')
    while True:
        try: raw=input('\ncybertrace> ')
        except (KeyboardInterrupt,EOFError):
            print('\n  Investigation session closed.')
            break
        try:
            if not dispatch(raw):break
        except (ValueError,UnicodeError,OSError,KeyError,json.JSONDecodeError) as exc:
            print(f'  [ERROR] {exc}')
    return 0

if __name__=='__main__':sys.exit(main())
