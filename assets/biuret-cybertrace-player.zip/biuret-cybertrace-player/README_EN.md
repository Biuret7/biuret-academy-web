# Biuret CyberTrace — The Insider Threat

**Category:** Forensics / Python / Secure Code Review / Misc  
**Suggested difficulty:** Medium (3/5)  
**Estimated duration:** 60–120 minutes  
**Requirements:** Python 3.10+, standard library only.

## Scenario
A fictional insider may have leaked a confidential company archive. Investigate the auth, network and file evidence; verify forensic integrity; recover a fragmented memo and a sealed custody receipt; submit the final flag.

## Run
Windows: `start_windows.bat` or `py cybertrace.py`  
Linux/macOS: `python3 cybertrace.py`

In the app, use `help` and `report`.

## Objectives
1. Identify the anomalous outbound transfer (destination, UTC time and bytes).
2. Correlate session, workstation, employee and accessed archive.
3. Find the modified file using a trusted SHA-256 baseline.
4. Write a small Python script to filter, CRC-check and reassemble shuffled base64 fragments.
5. Discover a verification command-path bug inside the **simulated** read-only dispatcher.
6. Obtain and decrypt the sealed custody receipt.
7. Derive the final `FLAG{...}` and submit it in the console.

## Fair-play rules
- All data is synthetic and the app makes no network calls.
- Source code and `evidence/` are in scope; helper scripts are encouraged.
- Do NOT open or edit `restricted/` directly. The protected receipt must be obtained through the intended in-app route.
- Do not modify the supplied evidence or bypass the built-in flag check by editing code.
- The dispatcher executes virtual read-only commands, **never OS commands**.

## Flag structure
`FLAG{EMPLOYEEID_ARCHIVE_STEM_RECEIPT_TOKEN}`

Employee ID without hyphen; uppercased archive stem with underscores; receipt token from decrypted custody receipt. Example only: `FLAG{E999_EXAMPLE_REPORT_ABC12345}`.
