#!/usr/bin/env python3
"""Standalone flag checker. Requires Python 3.9+ and no dependencies."""
import hashlib
import hmac

SALT = 'B1URET-CTF-04-v1-2026'
EXPECTED = '28136f43e84de140933be1eb53d618defba5a38d76ab7cf77cd6343461840975'

def main():
    print('Biuret CTF | Flag Validator')
    candidate = input('Enter flag: ').strip()
    submitted = hashlib.sha256((SALT + '::' + candidate).encode('utf-8')).hexdigest()
    if hmac.compare_digest(submitted, EXPECTED):
        print('SUCCESS - Correct flag!')
        return 0
    print('Incorrect flag. Keep investigating.')
    return 1

if __name__ == '__main__':
    raise SystemExit(main())
