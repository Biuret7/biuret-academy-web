"""Unittest coverage for the required public API. Do not edit."""
import unittest
from calculator import add, subtract, multiply, divide, average


class CalculatorTests(unittest.TestCase):
    def test_add_positive(self): self.assertEqual(add(8, 3), 11)
    def test_add_negative(self): self.assertEqual(add(-4, -6), -10)
    def test_add_zero(self): self.assertEqual(add(0, 12), 12)
    def test_subtract_order(self): self.assertEqual(subtract(12, 5), 7)
    def test_subtract_negative(self): self.assertEqual(subtract(-3, 4), -7)
    def test_subtract_same(self): self.assertEqual(subtract(2, 2), 0)
    def test_multiply_positive(self): self.assertEqual(multiply(4, 5), 20)
    def test_multiply_negative(self): self.assertEqual(multiply(-2, 4), -8)
    def test_multiply_zero(self): self.assertEqual(multiply(0, 10), 0)
    def test_divide_fraction(self): self.assertEqual(divide(7, 2), 3.5)
    def test_divide_negative(self): self.assertEqual(divide(-7, 2), -3.5)
    def test_divide_exact(self): self.assertEqual(divide(8, 4), 2)
    def test_divide_zero(self):
        with self.assertRaises(ZeroDivisionError): divide(5, 0)
    def test_average_integers(self): self.assertEqual(average([2, 4, 6]), 4)
    def test_average_fraction(self): self.assertEqual(average([1, 2]), 1.5)
    def test_average_floats(self): self.assertEqual(average([2.5, 3.5]), 3.0)
    def test_average_empty(self):
        with self.assertRaises(ValueError): average([])


if __name__ == "__main__": unittest.main()
