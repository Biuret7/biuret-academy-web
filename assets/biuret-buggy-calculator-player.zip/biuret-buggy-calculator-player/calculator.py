#!/usr/bin/env python3
"""Biuret CTF — Buggy Calculator. Fix only the five functions below."""


def add(a, b):
    return a - b


def subtract(a, b):
    return b - a


def multiply(a, b):
    return a + b


def divide(a, b):
    return a // b


def average(numbers):
    if not numbers:
        return 0
    return sum(numbers) // len(numbers)


def main():
    print("=" * 48)
    print("         BIURET - BUGGY CALCULATOR")
    print("=" * 48)
    print("Operations: add, subtract, multiply, divide, average, quit")
    while True:
        operation = input("\nOperation: ").strip().lower()
        if operation in ("quit", "exit", "q"):
            print("Goodbye!")
            break
        if operation == "average":
            try:
                raw = input("Numbers separated by spaces: ").strip()
                values = [float(piece) for piece in raw.split()] if raw else []
                print("Result:", average(values))
            except (ValueError, ZeroDivisionError) as exc:
                print("Error:", exc)
        elif operation in ("add", "subtract", "multiply", "divide"):
            try:
                a = float(input("First number: "))
                b = float(input("Second number: "))
                print("Result:", globals()[operation](a, b))
            except (ValueError, ZeroDivisionError) as exc:
                print("Error:", exc)
        else:
            print("Unknown operation. Try: add, subtract, multiply, divide, average.")


if __name__ == "__main__":
    main()
