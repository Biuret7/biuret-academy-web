# 04 — Buggy Calculator | Programming | Easy (1/5)

Five functions in `calculator.py` intentionally contain bugs. Fix `add`, `subtract`, `multiply`, `divide`, and `average` without altering their signatures. `divide` must use true division and raise `ZeroDivisionError` for zero denominators. `average([])` must raise `ValueError`. Run `python run_tests.py` to check all tests and receive the flag when they all pass. Modify **only** `calculator.py`. No dependencies. Score: 2 points per function.
