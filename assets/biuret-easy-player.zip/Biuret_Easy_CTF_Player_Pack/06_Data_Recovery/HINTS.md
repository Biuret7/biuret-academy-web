1. Check trailing commas and missing quotes.
2. Not every case in the export is relevant.
3. Sort by the numeric seq field before joining.
