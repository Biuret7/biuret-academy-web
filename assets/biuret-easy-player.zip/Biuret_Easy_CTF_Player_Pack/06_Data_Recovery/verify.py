from hashlib import sha256
from hmac import compare_digest

EXPECTED = "4507e630b028ba9367985799f943e3abbfc9e542dd943d35a667116e0488e393"
value = input("Submit flag: ").strip()
if compare_digest(sha256(value.encode()).hexdigest(), EXPECTED):
    print("[OK] Correct flag. Congratulations!")
else:
    print("[X] Incorrect flag. Try again.")
