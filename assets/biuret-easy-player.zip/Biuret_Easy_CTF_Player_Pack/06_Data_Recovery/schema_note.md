# Incident export schema

All records should be valid one-line JSON objects with: `case_id` (int), `seq` (int), `fragment` (str), and `valid` (bool).
Only **case 204** contains the final approved incident token. Ignore invalid and unrelated entries.
The token is split into sequential fragments joined with underscores. Submit in `FLAG{TOKEN}` format.
