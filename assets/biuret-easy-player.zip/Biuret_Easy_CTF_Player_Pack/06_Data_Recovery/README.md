# 06 — Data Recovery

**Category:** Programming  
**Difficulty:** Easy (2/5)  
**Score:** 25 platform CTF points  

## Mission
An export process generated broken JSON lines. Repair the records and reconstruct the approval token from the valid entries belonging to case 204.

## Getting started
Inspect `damaged_export.jsonl` and `schema_note.md`. Write your own recovery script if helpful.

## Your objectives
1. Repair the malformed records.
2. Keep only case_id 204 and valid = true.
3. Sort by seq and join the `fragment` fields.
4. Wrap the result inside `FLAG{...}`.

## Rules
Work only with the supplied fictional/local data. Python 3.9+; no external dependencies. Submit the exact `FLAG{...}` value using `python verify.py`. You may create your own analysis scripts.

## Hint policy
Hints are in `HINTS.md`. Biuret Academy does not deduct platform points for using these hints.
