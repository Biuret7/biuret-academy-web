from hashlib import sha256
from hmac import compare_digest

EXPECTED = "3d4fa5796c1ed53bb9e555ea358acc16bedafd37f8907653cbb6c0caab031148"
value = input("Submit flag: ").strip()
if compare_digest(sha256(value.encode()).hexdigest(), EXPECTED):
    print("[OK] Correct flag. Congratulations!")
else:
    print("[X] Incorrect flag. Try again.")
