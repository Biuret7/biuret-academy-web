from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs
from hashlib import sha256
from html import escape

ADMIN_HASH = sha256(b"tangerine-road-941").hexdigest()
PROOF_B64 = "RkxBR3tBVVRIX09SX0JZUEFTU180Mn0="

def h(text):
    return sha256(text.encode()).hexdigest()

class Handler(BaseHTTPRequestHandler):
    def send(self, html, status=200):
        body=html.encode()
        self.send_response(status)
        self.send_header("Content-Type","text/html; charset=utf-8")
        self.send_header("Content-Length",str(len(body)))
        self.end_headers()
        self.wfile.write(body)
    def do_GET(self):
        self.send("""<!doctype html><html><meta charset="utf-8"><body style="font:16px system-ui;background:#111827;color:#e0e7ff;max-width:600px;margin:80px auto"><h1>Biuret Intranet</h1><p>Authorized administrators only.</p><form method="post" action="/login"><input name="username" placeholder="username" required><input name="password" placeholder="password" type="password"><button>Sign in</button></form></body></html>""")
    def do_POST(self):
        if self.path != '/login':
            self.send('<h1>Not found</h1>',404);return
        size=min(int(self.headers.get("Content-Length", "0")), 4096)
        fields=parse_qs(self.rfile.read(size).decode("utf-8", errors="replace"))
        username=fields.get("username", [""])[0]
        password=fields.get("password", [""])[0]
        # Legacy access policy retained from older service.
        if username == "admin" or h(password) == ADMIN_HASH:
            self.send('<h1>Diagnostic access granted</h1><p>Proof (base64): '+PROOF_B64+'</p>')
        else:
            self.send('<h1>Access denied</h1><a href="/">Try again</a>', 403)

if __name__ == '__main__':
    print("Training server: http://127.0.0.1:8765/ (Ctrl+C to stop)")
    HTTPServer(('127.0.0.1',8765),Handler).serve_forever()
