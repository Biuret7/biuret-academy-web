# 04 — Broken Login

**Category:** Web Security  
**Difficulty:** Easy (2/5)  
**Score:** 25 platform CTF points  

## Mission
A fictional intranet has a role check that should restrict staff diagnostics. Inspect and test the supplied local training server to prove the authorization flaw.

## Getting started
Run `python server.py` and open `http://127.0.0.1:8765/` in your browser. If the port is in use, close other test servers first.

## Your objectives
1. Observe how the sign-in form behaves.
2. Read `server.py` to identify the flawed Boolean condition.
3. Reach the restricted diagnostics page without knowing the admin password.
4. Decode the proof shown there.

## Rules
Work only with the supplied fictional/local data. Python 3.9+; no external dependencies. Submit the exact `FLAG{...}` value using `python verify.py`. You may create your own analysis scripts.

## Hint policy
Hints are in `HINTS.md`. Biuret Academy does not deduct platform points for using these hints.
