1. Focus on the role check inside the POST handler.
2. In Python, `or` needs only one side to be True.
3. Try a username that satisfies the first condition with an incorrect password.
