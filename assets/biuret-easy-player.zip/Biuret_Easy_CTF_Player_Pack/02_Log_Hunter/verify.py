from hashlib import sha256
from hmac import compare_digest

EXPECTED = "179ef7b40720304cd98c2ca4c2527d2e3c5fff064b7212f67b13af40410474f3"
value = input("Submit flag: ").strip()
if compare_digest(sha256(value.encode()).hexdigest(), EXPECTED):
    print("[OK] Correct flag. Congratulations!")
else:
    print("[X] Incorrect flag. Try again.")
