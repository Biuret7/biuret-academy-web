1. Group failed attempts by both IP and user.
2. The suspicious success is followed by an outbound transfer.
3. Join `session_id` between files.
