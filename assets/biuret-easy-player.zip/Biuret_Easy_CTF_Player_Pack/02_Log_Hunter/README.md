# 02 — Log Hunter

**Category:** Forensics  
**Difficulty:** Easy (2/5)  
**Score:** 25 platform CTF points  

## Mission
A local server shows repeated login failures and an unexpected success. Determine which IP breached an account and the incident ID assigned in the audit index.

## Getting started
Inspect `auth.log`, `audit_index.csv`, and `network.log`.

## Your objectives
1. Identify the IP with 3+ failed attempts and a later success for the same account.
2. Confirm the successful session made a data transfer.
3. Read the incident ID for that session from the audit index.
4. Format as `FLAG{INCIDENT_IP}` with dots replaced by underscores.

## Rules
Work only with the supplied fictional/local data. Python 3.9+; no external dependencies. Submit the exact `FLAG{...}` value using `python verify.py`. You may create your own analysis scripts.

## Hint policy
Hints are in `HINTS.md`. Biuret Academy does not deduct platform points for using these hints.
