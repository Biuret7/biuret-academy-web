# 03 — Username Hunter 2

**Category:** OSINT (offline)  
**Difficulty:** Easy (2/5)  
**Score:** 25 platform CTF points  

## Mission
An anonymous researcher left clues on fictional community profiles. Identify the old handle connected to the current pseudonym, then recover the public proof token in a local archive.

## Getting started
Start by opening `hub/index.html` in a browser, then inspect local pages and data files in `hub/`.

## Your objectives
1. Identify the researcher’s current public handle.
2. Follow the clue to their archived handle.
3. Find the matching archived post and combine its three token fragments as `FLAG{PART1_PART2_PART3}`.

## Rules
Work only with the supplied fictional/local data. Python 3.9+; no external dependencies. Submit the exact `FLAG{...}` value using `python verify.py`. You may create your own analysis scripts.

## Hint policy
Hints are in `HINTS.md`. Biuret Academy does not deduct platform points for using these hints.
