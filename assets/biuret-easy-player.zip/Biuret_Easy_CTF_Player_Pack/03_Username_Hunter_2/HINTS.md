1. Open the profile card that mentions incident research.
2. The profile bio mentions an old alias.
3. The three fragment values are kept in order within the archived note.
