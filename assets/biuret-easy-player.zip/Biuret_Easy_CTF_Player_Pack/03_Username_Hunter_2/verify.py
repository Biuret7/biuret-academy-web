from hashlib import sha256
from hmac import compare_digest

EXPECTED = "f39efeeae1ebdd2d16f9ed598cc413ef0d7fbcfe8016648efbae707e85bf0a21"
value = input("Submit flag: ").strip()
if compare_digest(sha256(value.encode()).hexdigest(), EXPECTED):
    print("[OK] Correct flag. Congratulations!")
else:
    print("[X] Incorrect flag. Try again.")
