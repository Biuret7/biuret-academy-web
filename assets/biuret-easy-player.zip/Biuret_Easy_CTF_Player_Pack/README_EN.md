# Biuret Easy CTF — Player Release

Six standalone Easy (2/5) challenges, 25 platform CTF points each. Python 3.9+ required; standard library only. No internet access required.

Open each challenge folder, read its `README.md`, solve it, then run `python verify.py` and enter the answer in `FLAG{...}` format. The challenge data and fictional identities are local only.

For the web challenge, start `python server.py` and navigate to `http://127.0.0.1:8765/`. Stop the test server with Ctrl+C.

The `HINTS.md` files provide progressively stronger hints.


Each challenge awards 25 platform CTF points, 100 XP and 10 coins for eligible accounts. Submit the flag on the website to save your achievement. No hint penalty is applied.