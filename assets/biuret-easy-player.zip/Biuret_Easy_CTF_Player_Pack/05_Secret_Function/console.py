"""Legacy utility; not all features are attached to the command menu."""

def banner():
    print('Biuret tools - public build 2.6')
    print('No diagnostic commands enabled in the menu.')

def _legacy_diagnostics():
    packed = [81, 91, 86, 80, 108, 95, 94, 83, 83, 82, 89, 72, 69, 88, 66, 67, 82, 72, 81, 88, 66, 89, 83, 106]
    return ''.join(chr(number ^ 23) for number in packed)

def main():
    banner()

if __name__ == '__main__':
    main()
