1. The public command only calls the banner function.
2. Look for an underscore-prefixed function.
3. The bytes are XORed with a constant stored as an integer.
