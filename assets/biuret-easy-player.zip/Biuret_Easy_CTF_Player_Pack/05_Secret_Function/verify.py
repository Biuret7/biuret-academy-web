from hashlib import sha256
from hmac import compare_digest

EXPECTED = "64c6a58975aa9b16dd5c86208efb39ceb9a3f7df07a42cc2d4a28c7556d37b45"
value = input("Submit flag: ").strip()
if compare_digest(sha256(value.encode()).hexdigest(), EXPECTED):
    print("[OK] Correct flag. Congratulations!")
else:
    print("[X] Incorrect flag. Try again.")
