# 05 — Secret Function

**Category:** Reverse Engineering  
**Difficulty:** Easy (2/5)  
**Score:** 25 platform CTF points  

## Mission
An abandoned command-line utility prints only a welcome message, but an unused function still contains a secret diagnostic output. Explore the code to retrieve it.

## Getting started
Run `python console.py`, then inspect `console.py` in an editor.

## Your objectives
1. Find a function never called by the main menu.
2. Understand its byte transformation.
3. Invoke it or reproduce the transformation to reveal the Flag.

## Rules
Work only with the supplied fictional/local data. Python 3.9+; no external dependencies. Submit the exact `FLAG{...}` value using `python verify.py`. You may create your own analysis scripts.

## Hint policy
Hints are in `HINTS.md`. Biuret Academy does not deduct platform points for using these hints.
