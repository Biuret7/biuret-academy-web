# 01 — XOR Mystery

**Category:** Cryptography  
**Difficulty:** Easy (2/5)  
**Score:** 25 platform CTF points  

## Mission
A support desk sent the secret code over a test channel. The payload was protected with a repeated one-byte XOR key; the key was lost. Recover the code without guessing a password manually.

## Getting started
Read `intercept.txt` and `packet_note.txt`.

## Your objectives
1. Identify the encoding format.
2. Test possible one-byte XOR keys.
3. Find a readable flag and submit it.

## Rules
Work only with the supplied fictional/local data. Python 3.9+; no external dependencies. Submit the exact `FLAG{...}` value using `python verify.py`. You may create your own analysis scripts.

## Hint policy
Hints are in `HINTS.md`. Biuret Academy does not deduct platform points for using these hints.
