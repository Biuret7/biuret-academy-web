1. Hex bytes are not a cipher by themselves.
2. A single-byte XOR has only 256 possible keys.
3. A correct result starts with FLAG{.
