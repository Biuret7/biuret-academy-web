from hashlib import sha256
from hmac import compare_digest

EXPECTED = "ca157859c61942277bafafdb5cdd81ec67279a760c59dfbf4327cea9c4ef7ad0"
value = input("Submit flag: ").strip()
if compare_digest(sha256(value.encode()).hexdigest(), EXPECTED):
    print("[OK] Correct flag. Congratulations!")
else:
    print("[X] Incorrect flag. Try again.")
