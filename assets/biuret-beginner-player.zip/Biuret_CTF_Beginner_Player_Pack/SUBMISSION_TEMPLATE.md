# CTF Player Submission

**Player / Team:** ___________________  
**Date:** ___________________

| Challenge | Flag | Brief methodology | Hints used |
|---|---|---|---|
| Hidden Message | | | |
| Username Hunter | | | |
| Hidden Pixel | | | |
| Buggy Calculator | | | |

Note: The organizer decides whether partial points are earned from methodology.
