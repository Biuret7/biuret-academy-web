# Biuret CTF — Beginner Challenge Pack

Four independent easy (1/5) challenges, 10 points each, 40 points total. Each folder contains Arabic/English instructions and a local `verify.py` flag checker. All cases are fictional and legal offline exercises. Python 3.9+ is required; Hidden Pixel additionally uses Pillow. Start with `README_AR.md` or `README_EN.md` inside each challenge. Do not tamper with challenge validators; only Buggy Calculator allows modifying `calculator.py`.

| Challenge | Category | Approximate time | Points |
|---|---|---|---|
| Hidden Message | Cryptography | 10–20 min | 10 |
| Username Hunter | OSINT | 10–20 min | 10 |
| Hidden Pixel | Steganography | 20–35 min | 10 |
| Buggy Calculator | Programming | 15–30 min | 10 |

Keep answers private until the organizer completes grading.
