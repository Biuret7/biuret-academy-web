#!/usr/bin/env python3
"""
Biuret Vault - Python Security Challenge
Difficulty: Medium

This application intentionally contains security mistakes for a local CTF.
Do not reuse these patterns in real software.
"""

from pathlib import Path
import json
import hashlib
import base64
import sys

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
NOTES_DIR = DATA_DIR / "notes"
USERS_FILE = DATA_DIR / "users.json"
VAULT_FILE = DATA_DIR / "vault" / "vault.enc"

BUILD_ID = "BV-17-ALPHA"
LEGACY_ADMIN_HASH = "7f7aff87f092ff1e70a8816f7116243cba7e7d667dae0dfd44eba7b97357297e"

session = {
    "username": "guest",
    "role": "user"
}

def h(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def load_users():
    with open(USERS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def banner():
    print("=" * 58)
    print("             BIURET VAULT - SECURITY LAB")
    print("=" * 58)
    print("Type 'help' to see available commands.\n")

def help_menu():
    print("""
Available commands:
  help                  Show this help menu
  whoami                Show current session
  list                  List available notes
  read <filename>       Read a note
  search <word>         Search note names
  login                 Log in to another account
  admin                 Open the admin panel
  vault                 Access the protected vault
  logout                Return to guest session
  clear                  Clear the screen
  exit                   Exit the program
""")

def whoami():
    print(f"User : {session['username']}")
    print(f"Role : {session['role']}")

def list_notes():
    files = [p.name for p in NOTES_DIR.iterdir() if p.is_file()]
    if not files:
        print("No notes found.")
        return
    print("Notes:")
    for name in sorted(files):
        print(f"  - {name}")

def read_note(filename):
    # Open a note relative to the notes directory.
    target = NOTES_DIR / filename

    try:
        with open(target, "r", encoding="utf-8") as f:
            print(f.read())
    except FileNotFoundError:
        print("File not found.")
    except UnicodeDecodeError:
        print("This file is not a readable text file.")
    except IsADirectoryError:
        print("That path is a directory.")

def search_notes(term):
    matches = []
    term = term.lower()
    for p in NOTES_DIR.iterdir():
        if p.is_file() and term in p.name.lower():
            matches.append(p.name)

    if matches:
        print("Matches:")
        for name in sorted(matches):
            print(f"  - {name}")
    else:
        print("No matching note names.")

def login():
    username = input("Username: ").strip()
    password = input("Password: ").strip()

    users = load_users()
    record = users.get(username)

    if record and h(password) == record["password_hash"]:
        session["username"] = username
        session["role"] = record["role"]
        print(f"Logged in as {username}.")
        return

    # Legacy compatibility path retained after the v2 migration.
    if h(password) == LEGACY_ADMIN_HASH:
        session["username"] = username or "unknown"
        session["role"] = "admin"
        print("Legacy compatibility login accepted.")
        return

    print("Invalid credentials.")

def logout():
    session["username"] = "guest"
    session["role"] = "user"
    print("Returned to guest session.")

def admin_panel():
    if session["role"] != "admin":
        print("Access denied: administrator role required.")
        return

    print("""
--- ADMIN PANEL ---
System status : ONLINE
Vault status  : LOCKED
Hint          : the vault key was built from a short project code
                and the year of the legacy migration.
""")

def xor_bytes(data, key):
    return bytes(b ^ key[i % len(key)] for i, b in enumerate(data))

def vault():
    if session["role"] != "admin":
        print("Access denied: administrator role required.")
        return

    print("Encrypted vault payload:")
    print(VAULT_FILE.read_text(encoding="utf-8").strip())
    key = input("\nVault key: ").strip()

    try:
        raw = base64.b64decode(VAULT_FILE.read_text(encoding="utf-8").strip())
        plaintext = xor_bytes(raw, key.encode("utf-8")).decode("utf-8")
    except Exception:
        print("Decryption failed.")
        return

    if plaintext.startswith("FLAG{") and plaintext.endswith("}"):
        print("\nVAULT OPENED")
        print(plaintext)
    else:
        print("Wrong key.")

def debug_console():
    # Hidden command: intentionally omitted from the help menu.
    print("--- INTERNAL DEBUG ---")
    print(f"Build ID       : {BUILD_ID}")
    print("Data root      : ./data")
    print("Notes root     : ./data/notes")
    print("Backup root    : ./data/backups")
    print("Legacy migration year: 2024")
    print("Warning        : legacy backup cleanup is still pending")

def clear_screen():
    print("\n" * 40)

def main():
    banner()
    while True:
        try:
            raw = input("vault> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye.")
            break

        if not raw:
            continue

        parts = raw.split(maxsplit=1)
        command = parts[0].lower()
        arg = parts[1] if len(parts) == 2 else ""

        if command == "help":
            help_menu()
        elif command == "whoami":
            whoami()
        elif command == "list":
            list_notes()
        elif command == "read":
            if not arg:
                print("Usage: read <filename>")
            else:
                read_note(arg)
        elif command == "search":
            if not arg:
                print("Usage: search <word>")
            else:
                search_notes(arg)
        elif command == "login":
            login()
        elif command == "admin":
            admin_panel()
        elif command == "vault":
            vault()
        elif command == "logout":
            logout()
        elif command == "clear":
            clear_screen()
        elif command == "debug":
            debug_console()
        elif command == "exit":
            print("Session closed.")
            break
        else:
            print("Unknown command.")

if __name__ == "__main__":
    main()
