# Biuret Vault – Python Security Challenge

**Difficulty:** Medium  
**Goal:** Reach the protected vault and recover the final flag.

## Rules

- Everything happens locally inside this challenge folder.
- You may read and modify your own copy of the challenge files.
- You may write helper scripts in Python.
- Do not use the internet to search for the final flag.
- Do not ask the organizer for passwords or hidden commands.
- The intended solution does **not** require deleting files, damaging the system, or attacking another machine.

## Start

Run:

```bash
python challenge.py
```

On Windows, this also works:

```powershell
py challenge.py
```

Initial account:

```text
username: guest
password: guest123
```

The application starts in a guest session automatically, so logging in is optional at first.

## Objectives

Your score is based on completing multiple objectives, not only finding the flag.

1. Discover something useful that is not shown in the normal help menu.
2. Find evidence of an old/legacy administrator account.
3. Recover the legacy administrator password.
4. Identify and exploit an authentication or authorization weakness.
5. Reach the admin area.
6. Recover the vault key.
7. Open the vault and submit the final flag.

## Important

Some information is intentionally split across multiple files and program behaviors.  
A small Python helper script may save you time.

Good luck.
