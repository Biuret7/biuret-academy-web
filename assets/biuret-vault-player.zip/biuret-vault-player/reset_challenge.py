from pathlib import Path
import json
import hashlib

BASE = Path(__file__).resolve().parent
USERS_FILE = BASE / "data" / "users.json"

def h(s):
    return hashlib.sha256(s.encode()).hexdigest()

users = {
    "guest": {
        "password_hash": h("guest123"),
        "role": "user"
    },
    "analyst": {
        "password_hash": h("packet42"),
        "role": "user"
    }
}

USERS_FILE.write_text(json.dumps(users, indent=2), encoding="utf-8")
print("Challenge state reset.")
