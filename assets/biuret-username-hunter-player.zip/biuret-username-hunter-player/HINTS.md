# HINTS — اقرأ تدريجيًا / Progressive hints

استخدم تلميحًا واحدًا فقط إذا توقفت. كل تلميح يكشف أكثر من السابق.

### Hint 1
الموقع الرئيسي `sites/index.html` يوصلك إلى 3 مواقع خيالية. ابدأ بالبحث عن `cipherfern` في DevBoard.

### Hint 2
المنشورات التعريفية قد تحتوي رابطًا أو اسم مستخدم لحساب آخر.

### Hint 3
افتح صفحة PhotoShelf للحساب المذكور في DevBoard، وفتّش عن قسم Public Case Proof.

