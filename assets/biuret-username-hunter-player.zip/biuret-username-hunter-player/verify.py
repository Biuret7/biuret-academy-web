#!/usr/bin/env python3
"""Standalone flag checker. Requires Python 3.9+ and no dependencies."""
import hashlib
import hmac

SALT = 'B1URET-CTF-02-v1-2026'
EXPECTED = 'a83033e8b3b54e17f27b5a1eff527d4f464db5e6d04c4bb502b7abf49f2ae852'

def main():
    print('Biuret CTF | Flag Validator')
    candidate = input('Enter flag: ').strip()
    submitted = hashlib.sha256((SALT + '::' + candidate).encode('utf-8')).hexdigest()
    if hmac.compare_digest(submitted, EXPECTED):
        print('SUCCESS - Correct flag!')
        return 0
    print('Incorrect flag. Keep investigating.')
    return 1

if __name__ == '__main__':
    raise SystemExit(main())
