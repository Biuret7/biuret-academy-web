# 02 — Username Hunter | OSINT | Easy (1/5)

Start with handle `cipherfern` on the fictional developer network. Open `sites/index.html` in your browser, follow public profile clues to a second platform, and collect the proof token (`FLAG{...}`). Validate using `python verify.py`.

All identities and webpages are fictional and offline; do NOT investigate real people. Points: first profile (2), linked handle (4), correct flag (4). Hints: `HINTS.md`.
